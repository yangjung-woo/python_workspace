interface Data {
	author: string;
	message: string;
}

export default Data;