interface Memo {
	title: string;
	contents: string;
}

export default Memo